// @ts-ignore
import * as http from 'superagent';
// @ts-ignore
import * as requestPromise from 'superagent-promise' ;


const request = requestPromise(http, global.Promise);

const Api = 'http://localhost:8080';

const responseBody = (res: Body) => res.body;

let token: string;


const tokenPlugin = (req: any) => {
    if (token) {
        req.set('authorization', `Token ${token}`);
    }
}

const requests = {
    delete: (url: string) =>
        request.del(`${Api}${url}`).use(tokenPlugin).then(responseBody),
    get: (url: string) =>
        request.get(`${Api}${url}`).use(tokenPlugin).then(responseBody),
    put: (url: string, body: any) =>
        request.put(`${Api}${url}`, body).use(tokenPlugin).then(responseBody),
    post: (url: string, body: any) =>
        request.post(`${Api}${url}`, body).use(tokenPlugin).then(responseBody)
};

const Auth = {
    current: () =>
        requests.get('/user'),
    login: (email: string, password: string) =>
        requests.post('/login', {user: {email, password}}),
    signup: (username: string, email: string, password: string) =>
        requests.post('/users', {user: {username, email, password}}),
    save: (user: any) =>
        requests.put('/user', {user})
};

const Administrator = {
    all: () =>
        requests.get(`/administrators?`),
    delete: (id: number) =>
        requests.delete(`/administrators/${id}`),
    get: (id: number) =>
        requests.get(`/articles/${id}`),
    update: (adminstrator: any) =>
        requests.put(`/administrators/${adminstrator.id}`, {adminstrator}),
    create: (adminstrator: any) =>
        requests.post('/administrators', {adminstrator})
};

const Veterinarians = {
    all: () =>
        requests.get(`/veterinarians`),
    get: (vetId: string) =>
        requests.get(`/veterinarians?vetid=${vetId}`),
    delete: (vetId: string) =>
        requests.delete(`/veterinarians/${vetId}`),
    update: (veterinarian: any) =>
        requests.put(`/veterinarians/${veterinarian.id}`, {veterinarian: veterinarian}),
    create: (veterinarian: any) =>
        requests.post('/veterinarians', {veterinarian})
};


export default {
    Administrator,
    Auth,
    setToken: (_token: string) => {
        token = _token;
    }
};
