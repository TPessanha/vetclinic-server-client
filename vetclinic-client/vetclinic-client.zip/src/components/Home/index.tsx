import Logo from './Logo';
import MainView from './MainView';
import React from 'react';
import agent from '../../agent';
import {connect} from 'react-redux';
import {HOME_PAGE_LOADED, HOME_PAGE_UNLOADED} from '../../constants/actionTypes';

const Promise = global.Promise;

const mapStateToProps = (state: any) => ({
    ...state.home,
    appName: state.common.appName,
    token: state.common.token
});

const mapDispatchToProps = (dispatch: any) => ({
    onLoad: (tab: string, pager: string, payload: string) =>
        dispatch({type: HOME_PAGE_LOADED, tab, pager, payload}),
    onUnload: () =>
        dispatch({type: HOME_PAGE_UNLOADED})
});

class Home extends React.Component {

    constructor(props: any) {
        super(props)
    }

    componentWillMount() {
        const employeePromise = agent.Employees.all;
        this.props.onLoad('all', employeePromise, Promise.all([agent.Employees.getAll(), employeePromise()]));
    }

    componentWillUnmount() {
        this.props.onUnload();
    }

    render() {
        return (
            <div className="home-page">

                <Logo token={this.props.token} appName={this.props.appName}></Logo>

                <div className="container page">
                    <div className="row">
                        <MainView/>

                        <div className="col-md-3">
                            <div className="sidebar">

                                <p>Popular Tags</p>

                                <Tags
                                    tags={this.props.tags}
                                    onClickTag={this.props.onClickTag}/>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        );
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Home);

